<div class="content-wrapper">
    <!-- Container-fluid starts -->
    <!-- Main content starts -->
    <div class="container-fluid">
        <div class="main-header" style="margin-top: 0px;">
            <h1 style="font-size: 30px; ">Wisata Kuliner</h1>
            <hr>
        </div>

        Kuliner


    </div>
    <!-- Main content ends -->
    <!-- Container-fluid ends -->
</div>
</div>