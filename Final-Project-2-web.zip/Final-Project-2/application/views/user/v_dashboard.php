<section class="content-header">
    <h1 style="font-size: 30px; text-align:center;">SISTEM INFORMASI WISATA KOTA DEPOK</h1>
</section>
<section class="content">
    <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
            <p style="font-size: 20px; text-align:center;">SIWIKODE adalah website aplikasi yang dibuat untuk mengetahui lokasi-lokasi wisata di Kota Depok
                baik wisata kuliner dan rekreasi yang pastinya berguna bagi para pendatang maupun warga Depok sendiri yang belum mengetahui lokasi wisata di Kota Depok
            </p>
            <div class="row dashboard-header ">
                <div class="col-lg-4 col-md-6">
                    <div class="card dashboard-product bg-primary">
                        <span>Religi</span>
                        <h2 class="dashboard-total-products">
                            <?= $jumlah_religi ?>
                        </h2>
                        <a href="<?= site_url('User/rekreasi#WaterPark') ?>" class="btn bg-white" type="button">Lihat semua</a>
                        <div style="margin-right: 25px;" class="side-box">
                            <i class="ti-signal text-white-color"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card dashboard-product bg-primary">
                        <span>Taman Wisata</span>
                        <h2 class="dashboard-total-products">
                            <?= $jumlah_taman_wisata ?>
                        </h2>
                        <a href="<?= site_url('User/rekreasi#WaterPark') ?>" class="btn bg-white" type="button">Lihat semua</a>
                        <div style="margin-right: 25px;" class="side-box">
                            <i class="ti-signal text-white-color"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card dashboard-product bg-primary">
                        <span>Water Park</span>
                        <h2 class="dashboard-total-products">
                            <?= $jumlah_water_park ?>
                        </h2>
                        <a href="<?= site_url('User/rekreasi#WaterPark') ?>" class="btn bg-white" type="button">Lihat semua</a>
                        <div style="margin-right: 25px;" class="side-box">
                            <i class="ti-signal text-white-color"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>